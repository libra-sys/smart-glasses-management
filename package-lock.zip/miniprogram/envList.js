const envList = [
  { envId: 'cloud1-6gyt300c51f0e484', alias: 'cloud1-6gyt300c51f0e484' }
];
const isMac = false;
module.exports = {
  envList,
  isMac
};
